import { Routes } from '@angular/router';
import { Clientlayout } from './layouts/clientlayout/clientlayout';
import { Adminlayout } from './layouts/adminlayout/adminlayout';
import { Home } from './pages/home/home';
import { Dashboard } from './pages/dashboard/dashboard';

export const routes: Routes = [
    {path:'',component:Clientlayout,children:[
        {path:'',component:Home},
    ]},
    {path:'admin', component:Adminlayout,children:[
        {path:'',component:Dashboard}
    ]}
];

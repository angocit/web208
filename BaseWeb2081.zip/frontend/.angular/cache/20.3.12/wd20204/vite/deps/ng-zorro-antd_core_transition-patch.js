import {
  NzTransitionPatchDirective,
  NzTransitionPatchModule
} from "./chunk-WQIMUBQG.js";
import "./chunk-2EXATIYV.js";
import "./chunk-ZY5HDIHX.js";
export {
  NzTransitionPatchDirective as ɵNzTransitionPatchDirective,
  NzTransitionPatchModule as ɵNzTransitionPatchModule
};

import {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService,
  provideNzIcons,
  provideNzIconsPatch
} from "./chunk-ZHJKUINC.js";
import "./chunk-OTKM5M3P.js";
import "./chunk-EOZ4SESF.js";
import "./chunk-O43F7K4I.js";
import "./chunk-ZVQSTADZ.js";
import "./chunk-N3WALVAS.js";
import "./chunk-BV6YITCM.js";
import "./chunk-2EXATIYV.js";
import "./chunk-ZY5HDIHX.js";
export {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService,
  provideNzIcons,
  provideNzIconsPatch
};

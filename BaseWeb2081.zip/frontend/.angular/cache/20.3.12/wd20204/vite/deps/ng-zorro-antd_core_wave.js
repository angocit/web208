import {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
} from "./chunk-5R2L2MUV.js";
import "./chunk-OTKM5M3P.js";
import "./chunk-N3WALVAS.js";
import "./chunk-BV6YITCM.js";
import "./chunk-2EXATIYV.js";
import "./chunk-ZY5HDIHX.js";
export {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
};
